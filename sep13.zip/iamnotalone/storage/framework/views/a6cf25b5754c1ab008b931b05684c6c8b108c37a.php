<?php $__env->startSection('content'); ?>
    <div id="IynmQYRnfs">
        <script type="text/javascript" src="https://default.salsalabs.org/api/widget/template/5b26eb37-505d-436a-90c0-8e5276379511/?tId=IynmQYRnfs" ></script>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iamnotalone/public_html/iamnotalone/resources/views/donate.blade.php ENDPATH**/ ?>