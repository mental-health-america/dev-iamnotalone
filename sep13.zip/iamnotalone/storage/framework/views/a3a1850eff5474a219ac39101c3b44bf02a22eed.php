<?php echo e($slot); ?>

<?php /**PATH /home/iamnotalone/public_html/iamnotalone/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>