<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubCommentController extends Controller
{
    //
}
